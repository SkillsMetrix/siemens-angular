import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { EmpService } from '../../shared/emp.service';

@Component({
  selector: 'app-emp-add',
  templateUrl: './emp-add.component.html',
  styleUrl: './emp-add.component.css'
})
export class EmpAddComponent {
  empForm:FormGroup

  constructor(private fb:FormBuilder,private ds:EmpService){
    this.empForm=this.fb.group({
      uname:'',
      pass:'',
      email:'',
      doj:'',
      gender:'',
      industry:''
    })
  }
  industry:string[]=[
    'Finance','HR','IT'
  ]
  addUser(){
   this.ds.addUser(this.empForm.value);
    
  }
}
