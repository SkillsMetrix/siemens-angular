import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { EmpAddComponent } from './components/emp-add/emp-add.component';
import { EmpService } from './shared/emp.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
 constructor(private dialog:MatDialog,){}
  openAddEditForm(){
  this.dialog.open(EmpAddComponent)
 }
}
