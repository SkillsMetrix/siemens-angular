import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar'
import { MatIconModule } from '@angular/material/icon'
import { MatFormFieldModule } from '@angular/material/form-field'
import { MatInputModule } from '@angular/material/input'
import { MatDatepickerModule } from '@angular/material/datepicker'
import { MatNativeDateModule } from '@angular/material/core'
import { MatRadioModule } from '@angular/material/radio'
import { MatSelectModule } from '@angular/material/select'
import { MatTableModule } from '@angular/material/table'
import { MatPaginatorModule } from '@angular/material/paginator'
import { MatSortModule } from '@angular/material/sort'
import { MatSnackBarModule } from '@angular/material/snack-bar'

import { MatDialogModule } from '@angular/material/dialog';
import { EmpAddComponent } from './components/emp-add/emp-add.component';
import { EmpEditComponent } from './components/emp-edit/emp-edit.component'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { HttpClientModule } from '@angular/common/http'
@NgModule({
  declarations: [
    AppComponent,
    EmpAddComponent,
    EmpEditComponent
  ],
  imports: [
    MatIconModule, MatNativeDateModule, MatRadioModule,HttpClientModule,
     MatSelectModule,
     FormsModule,ReactiveFormsModule,
    BrowserModule, MatTableModule, MatPaginatorModule, MatSortModule, MatSnackBarModule,
    MatDialogModule,
    AppRoutingModule, MatFormFieldModule, MatDatepickerModule, MatInputModule,

    MatButtonModule, MatToolbarModule,

  ],
  providers: [
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
