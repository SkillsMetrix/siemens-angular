import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainApp } from './components/mainapp/mainapp.component';
import { Header } from './components/header/header.component';
import { Footer } from './components/footer/footer.component';
import { UserService } from './shared/services/User.service';
import { DatabindComponent } from './components/databind/databind.component';
import { FormsModule } from '@angular/forms'
@NgModule({
  // contains components/Pipes/Directives
  declarations: [
    AppComponent,MainApp,Header,Footer, DatabindComponent
  ],
  // modules
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule
  ],
  //services
  providers: [UserService],
  // launching component
  bootstrap: [AppComponent]
})
export class AppModule { }
