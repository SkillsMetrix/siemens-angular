import { Component, OnInit } from "@angular/core";
import { UserService } from "../../shared/services/User.service";


@Component({
    selector: 'header-app',
    styleUrls: ['header.component.css'],
    templateUrl: 'header.component.html'
})
export class Header implements OnInit{

  ngOnInit(): void {
    this.users=this.us.loadUserData()
  }

  users:string[]=[]

  constructor(private us:UserService){
  
  }

  
}