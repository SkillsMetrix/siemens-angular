import { Component } from "@angular/core";


@Component({
    selector: 'main-app',
    styleUrls: ['mainapp.component.css'],
    templateUrl: 'mainApp.component.html'
})
export class MainApp {

    message = 'welcome to mainapp'

}