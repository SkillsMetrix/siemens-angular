import { Component } from "@angular/core";


@Component({
    selector: 'footer-app',
    styleUrls: ['footer.component.css'],
    templateUrl: 'footer.component.html'
})
export class Footer {
    

 shopCart=[]    

}