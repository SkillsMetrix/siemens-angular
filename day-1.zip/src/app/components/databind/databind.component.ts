import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-databind',
  templateUrl: './databind.component.html',
  styleUrl: './databind.component.css'
})
export class DatabindComponent {

  addUser() {
    console.log('user added..!');

  }
  @Input()
  defaultName = 'manager'
  imageURL = 'https://media.sproutsocial.com/uploads/2022/06/profile-picture.jpeg'


  getColor(country: string) {
    switch (country) {
      case 'uk':
        return 'blue'
      case 'india':
        return 'green'
      default:
        return null
    }
  }
  people: any[] = [
    {
      name: 'amol',
      country: 'india',
      designation: 'manager'
    },
    {
      name: 'saurabh',
      country: 'uk',
      designation: 'admin'
    }
  ]


}
