import { Injectable } from "@angular/core";


@Injectable()
export class UserService{

    loadUserData():string[]{
        return ['admin','manager','qa']
    }
}